"""Adapters to external systems."""
from __future__ import annotations

import hashlib
import importlib
import logging
import os
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional, Sequence
from urllib.parse import urlparse

import psycopg

from .common import ConfigError, RuleEngineNotConfigured
from .settings import Settings

log = logging.getLogger(__name__)


@dataclass(frozen=True)
class ObjectInfo:
    bucket: str
    key: str
    version_id: Optional[str]
    etag: str
    size: int


def parse_uri(uri: str) -> tuple[str, str]:
    """s3://bucket/prefix/ -> (bucket, 'prefix/')."""
    p = urlparse(uri)
    if p.scheme not in ("s3", "local"):
        raise ValueError(f"unsupported storage URI {uri!r}")
    prefix = p.path.lstrip("/")
    if prefix and not prefix.endswith("/"):
        prefix += "/"
    return p.netloc, prefix


def basename(key: str) -> str:
    return key.rsplit("/", 1)[-1]


def dirname(key: str) -> str:
    return key.rsplit("/", 1)[0] + "/" if "/" in key else ""


def _hash_file(path, algorithm: str) -> str:
    h = hashlib.new(algorithm)
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_file(path: str) -> str:
    return _hash_file(path, "sha256")


class ObjectStore(ABC):
    @abstractmethod
    def head(self, bucket: str, key: str, version_id: Optional[str] = None) -> ObjectInfo: ...

    @abstractmethod
    def exists(self, bucket: str, key: str) -> bool: ...

    @abstractmethod
    def list_objects(self, bucket: str, prefix: str) -> list[ObjectInfo]: ...

    @abstractmethod
    def download(self, bucket: str, key: str, dest: str, version_id: Optional[str] = None) -> None: ...

    @abstractmethod
    def copy(self, src_bucket: str, src_key: str, dst_bucket: str, dst_key: str,
             version_id: Optional[str] = None) -> None: ...

    @abstractmethod
    def delete(self, bucket: str, key: str) -> None: ...

    def uri(self, bucket: str, key: str) -> str:
        return f"s3://{bucket}/{key}"

    def archive(self, bucket: str, key: str, folder: str, version_id: Optional[str] = None) -> str:
        """Move a file into <its own folder>/<folder>/; returns the new key."""
        dst_key = f"{dirname(key)}{folder}/{basename(key)}"
        self.copy(bucket, key, bucket, dst_key, version_id)
        self.delete(bucket, key)
        return dst_key


class LocalObjectStore(ObjectStore):
    """<root>/<bucket>/<key>."""

    def __init__(self, root: str):
        self.root = Path(root)

    def _path(self, bucket: str, key: str) -> Path:
        p = (self.root / bucket / key).resolve()
        if not p.is_relative_to(self.root.resolve()):
            raise ValueError("path escapes the local store root")
        return p

    def put(self, bucket: str, key: str, data: bytes) -> None:
        p = self._path(bucket, key)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)

    def head(self, bucket, key, version_id=None):
        p = self._path(bucket, key)
        if not p.is_file():
            raise FileNotFoundError(f"local://{bucket}/{key}")
        return ObjectInfo(bucket, key, None, _hash_file(p, "md5"), p.stat().st_size)

    def exists(self, bucket, key):
        return self._path(bucket, key).is_file()

    def list_objects(self, bucket, prefix):
        """Files directly under <bucket>/<prefix>, not recursive."""
        d = self._path(bucket, prefix)
        if not d.is_dir():
            return []
        return [ObjectInfo(bucket, f"{prefix}{p.name}", None, _hash_file(p, "md5"), p.stat().st_size)
                for p in sorted(d.iterdir()) if p.is_file()]

    def download(self, bucket, key, dest, version_id=None):
        shutil.copyfile(self._path(bucket, key), dest)

    def copy(self, src_bucket, src_key, dst_bucket, dst_key, version_id=None):
        dst = self._path(dst_bucket, dst_key)
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(self._path(src_bucket, src_key), dst)

    def delete(self, bucket, key):
        p = self._path(bucket, key)
        if p.exists():
            os.remove(p)


class S3ObjectStore(ObjectStore):
    def __init__(self, region: str):
        import boto3

        self.s3 = boto3.client("s3", region_name=region)

    def head(self, bucket, key, version_id=None):
        kw = {"Bucket": bucket, "Key": key}
        if version_id:
            kw["VersionId"] = version_id
        r = self.s3.head_object(**kw)
        etag = r["ETag"].strip('"')
        return ObjectInfo(bucket, key, r.get("VersionId") if r.get("VersionId") != "null" else None,
                          f"{etag}-{r['LastModified']:%Y%m%d%H%M%S}", r["ContentLength"])

    def exists(self, bucket, key):
        from botocore.exceptions import ClientError

        try:
            self.s3.head_object(Bucket=bucket, Key=key)
            return True
        except ClientError as e:
            if e.response.get("Error", {}).get("Code") in ("404", "NoSuchKey", "NotFound"):
                return False
            raise

    def list_objects(self, bucket, prefix):
        """Objects directly under prefix, not recursive."""
        out: list[ObjectInfo] = []
        paginator = self.s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=prefix, Delimiter="/"):
            for obj in page.get("Contents", []):
                if obj["Key"] == prefix:
                    continue
                out.append(ObjectInfo(bucket, obj["Key"], None, obj["ETag"].strip('"'), obj["Size"]))
        return out

    def download(self, bucket, key, dest, version_id=None):
        extra = {"VersionId": version_id} if version_id else None
        self.s3.download_file(bucket, key, dest, ExtraArgs=extra)

    def copy(self, src_bucket, src_key, dst_bucket, dst_key, version_id=None):
        src = {"Bucket": src_bucket, "Key": src_key}
        if version_id:
            src["VersionId"] = version_id
        self.s3.copy(src, dst_bucket, dst_key, ExtraArgs={"ServerSideEncryption": "aws:kms"})

    def delete(self, bucket, key):
        self.s3.delete_object(Bucket=bucket, Key=key)


def build_object_store(settings: Settings) -> ObjectStore:
    if settings.object_store == "local":
        return LocalObjectStore(settings.local_store_root)
    if settings.object_store == "s3":
        return S3ObjectStore(settings.aws_region)
    raise ValueError(f"unknown object store {settings.object_store!r}")


PASSED, PASSED_WITH_WARNINGS, FAILED, ERROR = "PASSED", "PASSED_WITH_WARNINGS", "FAILED", "ERROR"


@dataclass
class RuleOutcome:
    status: str
    failed_rules: list[str] = field(default_factory=list)
    warned_rules: list[str] = field(default_factory=list)
    error: Optional[str] = None

    @property
    def passed(self) -> bool:
        return self.status in (PASSED, PASSED_WITH_WARNINGS)


class RuleEngine(ABC):
    @abstractmethod
    def run(self, conn: psycopg.Connection, bindings: Sequence, run_params: dict, mode: str) -> RuleOutcome: ...


class CallableRuleEngine(RuleEngine):
    """Runs each bound GRE group/variant through `fn` and applies the validation mode."""

    def __init__(self, fn: Callable[..., list[dict]]):
        self.fn = fn

    def run(self, conn, bindings, run_params, mode):
        results: list[dict] = []
        try:
            for b in bindings:
                for r in self.fn(conn, b.gre_rule_group, b.gre_rule_variant, dict(run_params)):
                    if "rule_ref" not in r or "passed" not in r:
                        raise ValueError(f"rule engine returned an invalid result {r!r}")
                    results.append(r)
        except Exception as e:
            log.exception("rule engine technical failure")
            return RuleOutcome(ERROR, error=str(e))
        failed = [r["rule_ref"] for r in results if not r.get("passed")]
        if not failed:
            return RuleOutcome(PASSED)
        if mode == "GATE":
            return RuleOutcome(FAILED, failed_rules=failed)
        return RuleOutcome(PASSED_WITH_WARNINGS, warned_rules=failed)


class NoRulesEngine(RuleEngine):
    """Passes everything."""

    def run(self, conn, bindings, run_params, mode):
        return RuleOutcome(PASSED)


def _import(ref: str, what: str):
    module, _, attr = ref.partition(":")
    if not module or not attr:
        raise ConfigError(f"{what} must be 'module:name', got {ref!r}")
    return getattr(importlib.import_module(module), attr)


def build_rule_engine(settings: Settings) -> RuleEngine:
    if settings.rule_engine == "none":
        return NoRulesEngine()
    if settings.rule_engine != "gre":
        return _import(settings.rule_engine, "RULE_ENGINE")()
    if not settings.gre_entrypoint:
        def missing(*_a, **_k):
            raise RuleEngineNotConfigured("GRE_ENTRYPOINT is not set (open question Q-12: GRE call mechanics)")
        return CallableRuleEngine(missing)
    return CallableRuleEngine(_import(settings.gre_entrypoint, "GRE_ENTRYPOINT"))


@dataclass
class Message:
    subject: str
    body: str
    recipients: list[str]


class Channel(ABC):
    @abstractmethod
    def send(self, msg: Message) -> None: ...


class LogChannel(Channel):
    """Writes emails to the log instead of sending them (local development, tests)."""

    def __init__(self):
        self.sent: list[Message] = []

    def send(self, msg):
        self.sent.append(msg)
        log.warning("EMAIL to=%s | %s | %s", msg.recipients, msg.subject, msg.body.replace("\n", " / "))


class SesChannel(Channel):
    def __init__(self, settings: Settings):
        import boto3

        if not settings.notify_from_email:
            raise ConfigError("NOTIFY_FROM_EMAIL is required when NOTIFY_BACKEND=ses")
        self.sender = settings.notify_from_email
        self.ses = boto3.client("ses", region_name=settings.aws_region)

    def send(self, msg):
        if not msg.recipients:
            log.warning("no recipients for %r; not sent", msg.subject)
            return
        self.ses.send_email(Source=self.sender, Destination={"ToAddresses": msg.recipients},
                            Message={"Subject": {"Data": msg.subject[:200]}, "Body": {"Text": {"Data": msg.body}}})


def build_channel(settings: Settings) -> Channel:
    return SesChannel(settings) if settings.notify_backend == "ses" else LogChannel()
